import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.partnership_requests import Partnership_requestsService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/partnership_requests", tags=["partnership_requests"])


# ---------- Pydantic Schemas ----------
class Partnership_requestsData(BaseModel):
    """Entity data schema (for create/update)"""
    last_name: str
    first_name: str
    company: str
    phone: str
    message: str = None


class Partnership_requestsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    last_name: Optional[str] = None
    first_name: Optional[str] = None
    company: Optional[str] = None
    phone: Optional[str] = None
    message: Optional[str] = None


class Partnership_requestsResponse(BaseModel):
    """Entity response schema"""
    id: int
    last_name: str
    first_name: str
    company: str
    phone: str
    message: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class Partnership_requestsListResponse(BaseModel):
    """List response schema"""
    items: List[Partnership_requestsResponse]
    total: int
    skip: int
    limit: int


class Partnership_requestsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Partnership_requestsData]


class Partnership_requestsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Partnership_requestsUpdateData


class Partnership_requestsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Partnership_requestsBatchUpdateItem]


class Partnership_requestsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Partnership_requestsListResponse)
async def query_partnership_requestss(
    query: str = Query(None, description='Query conditions as JSON, e.g. {"id":2} or {"id":{"$gte":2}}'),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query partnership_requestss with filtering, sorting, and pagination"""
    logger.debug(f"Querying partnership_requestss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Partnership_requestsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} partnership_requestss")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.warning(f"Invalid partnership_requests query: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error querying partnership_requestss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Partnership_requestsListResponse)
async def query_partnership_requestss_all(
    query: str = Query(None, description='Query conditions as JSON, e.g. {"id":2} or {"id":{"$gte":2}}'),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query partnership_requestss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying partnership_requestss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Partnership_requestsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} partnership_requestss")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.warning(f"Invalid partnership_requests query: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error querying partnership_requestss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Partnership_requestsResponse)
async def get_partnership_requests(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single partnership_requests by ID"""
    logger.debug(f"Fetching partnership_requests with id: {id}, fields={fields}")
    
    service = Partnership_requestsService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Partnership_requests with id {id} not found")
            raise HTTPException(status_code=404, detail="Partnership_requests not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching partnership_requests {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Partnership_requestsResponse, status_code=201)
async def create_partnership_requests(
    data: Partnership_requestsData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new partnership_requests"""
    logger.debug(f"Creating new partnership_requests with data: {data}")
    
    service = Partnership_requestsService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create partnership_requests")
        
        logger.info(f"Partnership_requests created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating partnership_requests: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating partnership_requests: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Partnership_requestsResponse], status_code=201)
async def create_partnership_requestss_batch(
    request: Partnership_requestsBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple partnership_requestss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} partnership_requestss")
    
    service = Partnership_requestsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} partnership_requestss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Partnership_requestsResponse])
async def update_partnership_requestss_batch(
    request: Partnership_requestsBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple partnership_requestss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} partnership_requestss")
    
    service = Partnership_requestsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} partnership_requestss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Partnership_requestsResponse)
async def update_partnership_requests(
    id: int,
    data: Partnership_requestsUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing partnership_requests"""
    logger.debug(f"Updating partnership_requests {id} with data: {data}")

    service = Partnership_requestsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Partnership_requests with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Partnership_requests not found")
        
        logger.info(f"Partnership_requests {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating partnership_requests {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating partnership_requests {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_partnership_requestss_batch(
    request: Partnership_requestsBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple partnership_requestss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} partnership_requestss")
    
    service = Partnership_requestsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} partnership_requestss successfully")
        return {"message": f"Successfully deleted {deleted_count} partnership_requestss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_partnership_requests(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single partnership_requests by ID"""
    logger.debug(f"Deleting partnership_requests with id: {id}")
    
    service = Partnership_requestsService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Partnership_requests with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Partnership_requests not found")
        
        logger.info(f"Partnership_requests {id} deleted successfully")
        return {"message": "Partnership_requests deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting partnership_requests {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")