import { Award, Heart, Leaf, Clock } from "lucide-react";

const values = [
  {
    icon: Award,
    title: "Перевірені рецепти",
    description: "Наші рецепти передаються з покоління в покоління та зберігають автентичний смак.",
  },
  {
    icon: Leaf,
    title: "Натуральні інгредієнти",
    description: "Тільки найкращі натуральні спеції, м'ясо вищого ґатунку та свіжі молочні продукти — без штучних добавок.",
  },
  {
    icon: Heart,
    title: "Зроблено з любов'ю",
    description: "Кожен продукт виготовляється вручну з турботою — від ковбас до свіжоспеченого хліба.",
  },
  {
    icon: Clock,
    title: "Щодня свіже",
    description: "Наш хліб випікається щоранку, а м'ясні вироби та сири готуються невеликими партіями.",
  },
];

export default function AboutSection() {
  return (
    <section id="about" className="py-20 md:py-28 bg-[#FDF6EC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Text Content */}
          <div>
            <span className="text-[#C0392B] uppercase tracking-widest text-sm font-semibold">
              Наша історія
            </span>
            <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl font-bold text-[#1A1A1A] mt-2 mb-6">
              Справжній смак,
              <br />
              <span className="text-[#8B4513]">на вашому столі</span>
            </h2>
            <div className="space-y-4 text-[#6B5B4F] text-lg leading-relaxed">
              <p>
                Вже понад 15 років «М'ясничок» приносить справжні смаки натуральних
                продуктів нашим клієнтам. Те, що починалося як маленька сімейна кухня,
                виросло в надійного партнера для бізнесу та улюблене місце для кожної родини.
              </p>
              <p>
                Ми працюємо у форматах <strong>B2B</strong> та <strong>B2C</strong> —
                постачаємо продукцію ресторанам, кафе, магазинам та мережам, а також
                обслуговуємо роздрібних покупців напряму. Індивідуальний підхід до кожного
                клієнта — наш головний принцип.
              </p>
              <p>
                Наші ковбаси виготовляються за перевіреними рецептами з натурального м'яса
                та ароматних спецій. Сири — з місцевого молока, а лаваш випікається
                щоранку в традиційних печах.
              </p>
              <p>
                Ми віримо, що їжа — це більше, ніж просто харчування. Це зв'язок з
                культурою, родиною та традиціями. Кожен шматочок розповідає історію.
              </p>
            </div>
          </div>

          {/* Values Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {values.map((value) => (
              <div
                key={value.title}
                className="bg-white p-6 rounded-xl shadow-sm border border-[#F5E6D3] hover:shadow-md transition-shadow duration-300"
              >
                <div className="w-12 h-12 bg-[#C0392B]/10 rounded-lg flex items-center justify-center mb-4">
                  <value.icon className="w-6 h-6 text-[#C0392B]" />
                </div>
                <h3 className="font-['Playfair_Display'] text-lg font-bold text-[#1A1A1A] mb-2">
                  {value.title}
                </h3>
                <p className="text-[#6B5B4F] text-sm leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}