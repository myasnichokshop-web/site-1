import { useState } from "react";
import { X, Minus, Plus, Trash2, ShoppingCart, CheckCircle2 } from "lucide-react";
import { useCart } from "@/contexts/CartContext";

type CheckoutStep = "cart" | "checkout" | "success";

interface FormData {
  name: string;
  phone: string;
  email: string;
  address: string;
  paymentMethod: "cash" | "card";
  comment: string;
}

const initialForm: FormData = {
  name: "",
  phone: "",
  email: "",
  address: "",
  paymentMethod: "cash",
  comment: "",
};

export default function CartDrawer() {
  const { items, isOpen, closeCart, updateQuantity, removeItem, clearCart, totalItems, totalPrice } = useCart();
  const [step, setStep] = useState<CheckoutStep>("cart");
  const [form, setForm] = useState<FormData>(initialForm);
  const [submitting, setSubmitting] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  if (!isOpen) return null;

  const handleConfirmClear = () => {
    clearCart();
    setShowClearConfirm(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    // Simulate submission
    setTimeout(() => {
      setSubmitting(false);
      setStep("success");
      clearCart();
    }, 900);
  };

  const handleClose = () => {
    closeCart();
    // Reset to cart view after a short delay so user sees success flash
    setTimeout(() => {
      setStep("cart");
      setForm(initialForm);
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-[100] flex" role="dialog" aria-modal="true">
      {/* Overlay */}
      <button
        onClick={handleClose}
        aria-label="Закрити кошик"
        className="flex-1 bg-black/50 backdrop-blur-sm"
      />

      {/* Drawer */}
      <div className="relative w-full max-w-md bg-[#FDF6EC] shadow-2xl flex flex-col h-full animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-[#F5E6D3] bg-white">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-[#C0392B]" />
            <h2 className="font-['Playfair_Display'] text-xl font-bold text-[#1A1A1A]">
              {step === "cart" && "Ваш кошик"}
              {step === "checkout" && "Оформлення замовлення"}
              {step === "success" && "Замовлення прийнято"}
            </h2>
            {step === "cart" && totalItems > 0 && (
              <span className="text-sm text-[#6B5B4F]">({totalItems})</span>
            )}
          </div>
          <button
            onClick={handleClose}
            className="p-2 rounded-lg hover:bg-[#F5E6D3] transition-colors"
            aria-label="Закрити"
          >
            <X className="w-5 h-5 text-[#1A1A1A]" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {step === "cart" && (
            <>
              {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full p-8 text-center">
                  <ShoppingCart className="w-16 h-16 text-[#E0D5C7] mb-4" />
                  <p className="text-[#6B5B4F] text-lg font-medium mb-2">Кошик порожній</p>
                  <p className="text-[#8B7B6F] text-sm mb-6">
                    Додайте продукти з каталогу, щоб оформити замовлення.
                  </p>
                  <button
                    onClick={handleClose}
                    className="px-5 py-2.5 bg-[#C0392B] text-white font-semibold rounded-lg hover:bg-[#A93226] transition-colors"
                  >
                    До каталогу
                  </button>
                </div>
              ) : (
                <div className="p-4 space-y-3">
                  {items.map((item) => (
                    <div
                      key={item.id}
                      className="flex gap-3 bg-white p-3 rounded-xl border border-[#F5E6D3]"
                    >
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-20 h-20 object-cover rounded-lg flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-[10px] uppercase tracking-wider text-[#8B4513] font-semibold">
                          {item.category}
                        </p>
                        <h3 className="font-['Playfair_Display'] text-sm font-bold text-[#1A1A1A] leading-tight line-clamp-2 mb-1">
                          {item.name}
                        </h3>
                        <p className="text-xs text-[#6B5B4F] mb-2">
                          {item.priceLabel} / {item.weight}
                        </p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1 bg-[#F5E6D3]/60 rounded-lg">
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="p-1.5 hover:bg-[#F5E6D3] rounded-l-lg transition-colors"
                              aria-label="Зменшити"
                            >
                              <Minus className="w-3.5 h-3.5 text-[#1A1A1A]" />
                            </button>
                            <span className="px-2 text-sm font-semibold text-[#1A1A1A] min-w-[28px] text-center">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="p-1.5 hover:bg-[#F5E6D3] rounded-r-lg transition-colors"
                              aria-label="Збільшити"
                            >
                              <Plus className="w-3.5 h-3.5 text-[#1A1A1A]" />
                            </button>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-[#C0392B]">
                              {(item.price * item.quantity).toFixed(0)} ₴
                            </span>
                            <button
                              onClick={() => removeItem(item.id)}
                              className="p-1.5 text-[#8B7B6F] hover:text-[#C0392B] hover:bg-red-50 rounded-lg transition-colors"
                              aria-label="Видалити"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {step === "checkout" && (
            <form id="checkout-form" onSubmit={handleSubmit} className="p-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#6B5B4F] uppercase tracking-wider mb-1.5">
                  Ім'я *
                </label>
                <input
                  type="text"
                  name="name"
                  required
                  value={form.name}
                  onChange={handleChange}
                  placeholder="Ваше ім'я"
                  className="w-full px-3 py-2.5 bg-white border border-[#E0D5C7] rounded-lg text-sm text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#C0392B]/30 focus:border-[#C0392B]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#6B5B4F] uppercase tracking-wider mb-1.5">
                  Телефон *
                </label>
                <input
                  type="tel"
                  name="phone"
                  required
                  value={form.phone}
                  onChange={handleChange}
                  placeholder="+380..."
                  className="w-full px-3 py-2.5 bg-white border border-[#E0D5C7] rounded-lg text-sm text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#C0392B]/30 focus:border-[#C0392B]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#6B5B4F] uppercase tracking-wider mb-1.5">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  placeholder="email@example.com"
                  className="w-full px-3 py-2.5 bg-white border border-[#E0D5C7] rounded-lg text-sm text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#C0392B]/30 focus:border-[#C0392B]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#6B5B4F] uppercase tracking-wider mb-1.5">
                  Адреса доставки *
                </label>
                <input
                  type="text"
                  name="address"
                  required
                  value={form.address}
                  onChange={handleChange}
                  placeholder="Місто, вулиця, будинок, квартира"
                  className="w-full px-3 py-2.5 bg-white border border-[#E0D5C7] rounded-lg text-sm text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#C0392B]/30 focus:border-[#C0392B]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#6B5B4F] uppercase tracking-wider mb-1.5">
                  Спосіб оплати
                </label>
                <select
                  name="paymentMethod"
                  value={form.paymentMethod}
                  onChange={handleChange}
                  className="w-full px-3 py-2.5 bg-white border border-[#E0D5C7] rounded-lg text-sm text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#C0392B]/30 focus:border-[#C0392B]"
                >
                  <option value="cash">Готівкою при отриманні</option>
                  <option value="card">Карткою онлайн</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#6B5B4F] uppercase tracking-wider mb-1.5">
                  Коментар до замовлення
                </label>
                <textarea
                  name="comment"
                  value={form.comment}
                  onChange={handleChange}
                  rows={3}
                  placeholder="Додаткові побажання..."
                  className="w-full px-3 py-2.5 bg-white border border-[#E0D5C7] rounded-lg text-sm text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#C0392B]/30 focus:border-[#C0392B] resize-none"
                />
              </div>

              {/* Order summary inside checkout */}
              <div className="bg-white rounded-xl border border-[#F5E6D3] p-4">
                <h4 className="font-semibold text-sm text-[#1A1A1A] mb-3">Ваше замовлення</h4>
                <div className="space-y-1.5 mb-3">
                  {items.map((item) => (
                    <div key={item.id} className="flex justify-between text-xs text-[#6B5B4F]">
                      <span className="truncate pr-2">
                        {item.name} × {item.quantity}
                      </span>
                      <span className="font-semibold text-[#1A1A1A] whitespace-nowrap">
                        {(item.price * item.quantity).toFixed(0)} ₴
                      </span>
                    </div>
                  ))}
                </div>
                <div className="pt-3 border-t border-[#F5E6D3] flex justify-between items-center">
                  <span className="text-sm font-semibold text-[#1A1A1A]">Разом:</span>
                  <span className="text-lg font-bold text-[#C0392B]">{totalPrice.toFixed(0)} ₴</span>
                </div>
              </div>
            </form>
          )}

          {step === "success" && (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center">
              <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mb-5">
                <CheckCircle2 className="w-12 h-12 text-green-600" />
              </div>
              <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#1A1A1A] mb-3">
                Дякуємо за замовлення!
              </h3>
              <p className="text-[#6B5B4F] mb-2">
                Ми зв'яжемося з вами найближчим часом для підтвердження.
              </p>
              <p className="text-[#8B7B6F] text-sm mb-6">
                Перевірте ваш телефон — наш менеджер зателефонує протягом 15 хвилин.
              </p>
              <button
                onClick={handleClose}
                className="px-6 py-2.5 bg-[#C0392B] text-white font-semibold rounded-lg hover:bg-[#A93226] transition-colors"
              >
                Продовжити покупки
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        {step === "cart" && items.length > 0 && (
          <div className="border-t border-[#F5E6D3] bg-white p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-[#6B5B4F] text-sm">Загальна сума:</span>
              <span className="text-2xl font-bold text-[#C0392B]">{totalPrice.toFixed(0)} ₴</span>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowClearConfirm(true)}
                className="px-4 py-3 bg-[#F5E6D3] text-[#6B5B4F] font-semibold rounded-lg hover:bg-[#E0D5C7] transition-colors text-sm"
              >
                Очистити
              </button>
              <button
                onClick={() => setStep("checkout")}
                className="flex-1 px-5 py-3 bg-[#C0392B] text-white font-bold rounded-lg hover:bg-[#A93226] transition-colors"
              >
                Оформити замовлення
              </button>
            </div>
          </div>
        )}

        {step === "checkout" && (
          <div className="border-t border-[#F5E6D3] bg-white p-4 flex gap-2">
            <button
              onClick={() => setStep("cart")}
              className="px-4 py-3 bg-[#F5E6D3] text-[#6B5B4F] font-semibold rounded-lg hover:bg-[#E0D5C7] transition-colors text-sm"
            >
              Назад
            </button>
            <button
              type="submit"
              form="checkout-form"
              disabled={submitting}
              className="flex-1 px-5 py-3 bg-[#C0392B] text-white font-bold rounded-lg hover:bg-[#A93226] transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {submitting ? "Обробка..." : `Підтвердити • ${totalPrice.toFixed(0)} ₴`}
            </button>
          </div>
        )}

        {/* Clear cart confirmation */}
        {showClearConfirm && (
          <div className="absolute inset-0 z-10 flex items-center justify-center p-5 bg-black/40 backdrop-blur-sm">
            <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-6 animate-in fade-in zoom-in duration-200">
              <div className="flex items-center justify-center w-14 h-14 rounded-full bg-red-100 mx-auto mb-4">
                <Trash2 className="w-7 h-7 text-[#C0392B]" />
              </div>
              <h3 className="font-['Playfair_Display'] text-xl font-bold text-[#1A1A1A] text-center mb-2">
                Очистити кошик?
              </h3>
              <p className="text-[#6B5B4F] text-sm text-center mb-6">
                Ви впевнені, що хочете очистити ваш кошик? Усі додані товари будуть видалені.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="flex-1 px-4 py-2.5 bg-[#F5E6D3] text-[#6B5B4F] font-semibold rounded-lg hover:bg-[#E0D5C7] transition-colors text-sm"
                >
                  Скасувати
                </button>
                <button
                  onClick={handleConfirmClear}
                  className="flex-1 px-4 py-2.5 bg-[#C0392B] text-white font-semibold rounded-lg hover:bg-[#A93226] transition-colors text-sm"
                >
                  Так, очистити
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}