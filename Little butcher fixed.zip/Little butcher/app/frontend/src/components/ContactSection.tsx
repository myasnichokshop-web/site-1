import { MapPin, Phone, Mail, Clock } from "lucide-react";

const contactInfo = [
  {
    icon: MapPin,
    title: "Завітайте до нас",
    lines: ["вул. Хрещатик, 12", "Київ, 01001"],
  },
  {
    icon: Phone,
    title: "Зателефонуйте",
    lines: ["+380 (44) 555-01-42", "+380 (67) 555-01-43"],
  },
  {
    icon: Mail,
    title: "Напишіть нам",
    lines: ["info@myasnychok.ua", "zamovlennya@myasnychok.ua"],
  },
  {
    icon: Clock,
    title: "Графік роботи",
    lines: ["Пн–Сб: 8:00 – 20:00", "Неділя: вихідний"],
  },
];

export default function ContactSection() {
  return (
    <section id="contact" className="py-20 md:py-28 bg-[#1A1A1A]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-[#E8A87C] uppercase tracking-widest text-sm font-semibold">
            Зв'яжіться з нами
          </span>
          <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl font-bold text-white mt-2 mb-4">
            Наш магазин
          </h2>
          <p className="text-white/60 text-lg max-w-2xl mx-auto">
            Завітайте до нас особисто, щоб спробувати смаки наживо. Ми завжди раді вас бачити!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Info Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {contactInfo.map((item) => (
              <div
                key={item.title}
                className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6 hover:bg-white/10 transition-colors duration-300"
              >
                <div className="w-12 h-12 bg-[#C0392B]/20 rounded-lg flex items-center justify-center mb-4">
                  <item.icon className="w-6 h-6 text-[#C0392B]" />
                </div>
                <h3 className="font-['Playfair_Display'] text-lg font-bold text-white mb-3">
                  {item.title}
                </h3>
                {item.lines.map((line) => (
                  <p
                    key={line}
                    translate={line === "Неділя: вихідний" ? "no" : undefined}
                    className={`text-white/60 text-sm leading-relaxed ${line === "Неділя: вихідний" ? "notranslate" : ""}`}
                  >
                    {line === "Неділя: вихідний" && document.cookie.includes("googtrans=/uk/en") ? "Sunday: closed" : line}
                  </p>
                ))}
              </div>
            ))}
          </div>

          {/* Contact Form */}
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-8">
            <h3 className="font-['Playfair_Display'] text-2xl font-bold text-white mb-6">
              Надіслати повідомлення
            </h3>
            <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-white/60 text-sm mb-1.5 block">Ім'я</label>
                  <input
                    type="text"
                    placeholder="Іван"
                    className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-[#C0392B] transition-colors"
                  />
                </div>
                <div>
                  <label className="text-white/60 text-sm mb-1.5 block">Прізвище</label>
                  <input
                    type="text"
                    placeholder="Петренко"
                    className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-[#C0392B] transition-colors"
                  />
                </div>
              </div>
              <div>
                <label className="text-white/60 text-sm mb-1.5 block">Електронна пошта</label>
                <input
                  type="email"
                  placeholder="ivan@example.com"
                  className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-[#C0392B] transition-colors"
                />
              </div>
              <div>
                <label className="text-white/60 text-sm mb-1.5 block">Повідомлення</label>
                <textarea
                  rows={4}
                  placeholder="Розкажіть, що б ви хотіли замовити або запитати..."
                  className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-[#C0392B] transition-colors resize-none"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3.5 bg-[#C0392B] text-white font-semibold rounded-lg hover:bg-[#A93226] transition-colors duration-200 text-lg"
              >
                Надіслати
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}