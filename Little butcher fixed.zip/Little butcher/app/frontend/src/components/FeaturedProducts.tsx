import { Star, Flame, ShoppingCart } from "lucide-react";
import { useCart, parsePrice } from "@/contexts/CartContext";

const SAUSAGE_IMG = "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwkjycalia/p021.png";
const CHEESE_IMG = "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzseicalga/p090.png";
const LAVASH_IMG = "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzhracalhq/p064.png";

interface FeaturedItem {
  id: number;
  name: string;
  category: string;
  priceLabel: string;
  weight: string;
  image: string;
  badge: string;
  rating: number;
  reviews: number;
}

const featuredItems: FeaturedItem[] = [
  {
    id: 1001,
    name: "Ковбаса «Домашня мелена»",
    category: "Ковбаси",
    priceLabel: "300 ₴",
    weight: "кг",
    image: SAUSAGE_IMG,
    badge: "Хіт продажів",
    rating: 4.9,
    reviews: 128,
  },
  {
    id: 1002,
    name: "Сир косичка біла",
    category: "Молочне",
    priceLabel: "355 ₴",
    weight: "кг",
    image: CHEESE_IMG,
    badge: "Улюбленець",
    rating: 4.8,
    reviews: 96,
  },
  {
    id: 1003,
    name: "Масло «Фермерське»",
    category: "Молочне",
    priceLabel: "150 ₴",
    weight: "0,5 кг",
    image: LAVASH_IMG,
    badge: "Свіже щодня",
    rating: 5.0,
    reviews: 214,
  },
];

export default function FeaturedProducts() {
  const { addItem } = useCart();

  const handleAdd = (item: FeaturedItem) => {
    addItem({
      id: item.id,
      name: item.name,
      price: parsePrice(item.priceLabel),
      priceLabel: item.priceLabel,
      weight: item.weight,
      image: item.image,
      category: item.category,
    });
  };

  return (
    <section id="featured" className="py-20 md:py-28 bg-[#FDF6EC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Flame className="w-5 h-5 text-[#C0392B]" />
            <span className="text-[#C0392B] uppercase tracking-widest text-sm font-semibold">
              Найкраще
            </span>
            <Flame className="w-5 h-5 text-[#C0392B]" />
          </div>
          <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl font-bold text-[#1A1A1A] mb-4">
            Хіти продажів
          </h2>
          <p className="text-[#6B5B4F] text-lg max-w-2xl mx-auto">
            Улюблені смаки наших клієнтів — продукти, за якими повертаються знову і знову.
          </p>
        </div>

        {/* Featured Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featuredItems.map((item) => (
            <div
              key={item.id}
              className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 hover:-translate-y-2"
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-[#C0392B] text-white text-xs font-bold px-3 py-1.5 rounded-full uppercase tracking-wide">
                    {item.badge}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <p className="text-[#8B4513] text-sm font-medium uppercase tracking-wide mb-1">
                  {item.category}
                </p>
                <h3 className="font-['Playfair_Display'] text-xl font-bold text-[#1A1A1A] mb-2">
                  {item.name}
                </h3>
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < Math.floor(item.rating)
                            ? "text-yellow-400 fill-yellow-400"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-[#6B5B4F]">
                    {item.rating} ({item.reviews})
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-[#C0392B]">
                    {item.priceLabel}
                    <span className="text-sm text-[#6B5B4F] font-normal ml-1">/ {item.weight}</span>
                  </span>
                  <button
                    onClick={() => handleAdd(item)}
                    className="flex items-center gap-1.5 px-4 py-2 bg-[#1A1A1A] text-white text-sm font-semibold rounded-lg hover:bg-[#333] transition-colors duration-200"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    Додати
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}