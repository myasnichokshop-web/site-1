import { ShoppingBasket } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[#111111] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <ShoppingBasket className="w-7 h-7 text-[#C0392B]" />
              <span className="font-['Playfair_Display'] text-xl font-bold text-white">
                М'яс<span className="text-[#C0392B]">ничок</span>
              </span>
            </div>
            <p className="text-white/40 text-sm leading-relaxed">
              Натуральні ковбаси, сири та свіжоспечений хліб. Приносимо традиції на ваш стіл уже понад 15 років.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
              Навігація
            </h4>
            <ul className="space-y-2.5">
              {[
                { label: "Головна", href: "#home" },
                { label: "Продукція", href: "#products" },
                { label: "Хіти продажів", href: "#featured" },
                { label: "Про нас", href: "#about" },
                { label: "Контакти", href: "#contact" },
              ].map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-white/40 hover:text-[#C0392B] transition-colors text-sm"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Products */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
              Продукція
            </h4>
            <ul className="space-y-2.5">
              {["Ковбаси", "М'ясні делікатеси", "Снеки", "Молочне", "Заморожені", "Бакалія"].map((item) => (
                <li key={item}>
                  <a
                    href="#products"
                    className="text-white/40 hover:text-[#C0392B] transition-colors text-sm"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
              Розсилка
            </h4>
            <p className="text-white/40 text-sm mb-4">
              Підпишіться на щотижневі акції та новинки асортименту.
            </p>
            <form className="flex gap-2" onSubmit={(e) => e.preventDefault()}>
              <input
                type="email"
                placeholder="Ваш email"
                className="flex-1 bg-white/5 border border-white/20 rounded-lg px-4 py-2.5 text-white placeholder-white/30 text-sm focus:outline-none focus:border-[#C0392B] transition-colors"
              />
              <button
                type="submit"
                className="px-4 py-2.5 bg-[#C0392B] text-white text-sm font-semibold rounded-lg hover:bg-[#A93226] transition-colors"
              >
                OK
              </button>
            </form>
            {/* Social Links */}
            <div className="flex items-center gap-4 mt-6">
              {["Facebook", "Instagram", "Telegram"].map((social) => (
                <a
                  key={social}
                  href="#"
                  className="text-white/30 hover:text-[#C0392B] transition-colors text-sm"
                >
                  {social}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/5 mt-10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-white/30 text-sm">
            © 2025 М'ясничок. Усі права захищені.
          </p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-white/30 hover:text-white/60 transition-colors text-sm">
              Політика конфіденційності
            </a>
            <a href="#" className="text-white/30 hover:text-white/60 transition-colors text-sm">
              Умови використання
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}