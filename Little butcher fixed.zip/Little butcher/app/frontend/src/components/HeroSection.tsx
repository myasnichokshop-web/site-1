import { ArrowDown } from "lucide-react";

const HERO_IMAGE = "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-03-30/a26f839d-8ecf-4590-b355-e94c1d69abab.png";

export default function HeroSection() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={HERO_IMAGE}
          alt="М'ясничок — найкращі ковбаси та делікатеси"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <p className="text-[#F5E6D3] uppercase tracking-[0.3em] text-sm md:text-base mb-4 font-medium animate-in fade-in slide-in-from-bottom-4 duration-700">
          Справжній смак якості
        </p>
        <h1 className="font-['Playfair_Display'] text-4xl sm:text-5xl md:text-7xl font-bold text-white mb-6 leading-tight animate-in fade-in slide-in-from-bottom-6 duration-700 delay-150">
          Ковбаси, сири
          <br />
          <span className="text-[#E8A87C]">та лаваш</span>
        </h1>
        <p className="text-white/80 text-lg md:text-xl max-w-2xl mx-auto mb-10 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300">
          Від нашої родини до вашої — натуральні м'ясні вироби, ремісничі сири
          та свіжоспечений хліб, створені з любов'ю та традиціями.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-in fade-in slide-in-from-bottom-10 duration-700 delay-500">
          <a
            href="#products"
            className="px-8 py-4 bg-[#C0392B] text-white font-semibold rounded-lg hover:bg-[#A93226] transition-all duration-200 text-lg shadow-lg hover:shadow-xl hover:-translate-y-0.5"
          >
            Переглянути продукцію
          </a>
          <a
            href="#about"
            className="px-8 py-4 border-2 border-white/40 text-white font-semibold rounded-lg hover:bg-white/10 transition-all duration-200 text-lg"
          >
            Наша історія
          </a>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <a href="#featured" className="text-white/60 hover:text-white transition-colors">
          <ArrowDown className="w-6 h-6" />
        </a>
      </div>
    </section>
  );
}