const setLang = (lang: "uk" | "en") => {
  const host = window.location.hostname;
  const expire = "expires=Thu, 01 Jan 1970 00:00:00 GMT";
  document.cookie = `googtrans=; ${expire}; path=/`;
  document.cookie = `googtrans=; ${expire}; path=/; domain=${host}`;
  document.cookie = `googtrans=; ${expire}; path=/; domain=.${host}`;
  if (lang === "en") document.cookie = "googtrans=/uk/en; path=/";
  window.location.reload();
};

const currentLang = () => (document.cookie.includes("googtrans=/uk/en") ? "en" : "uk");

export default function LanguageSwitcher() {
  const active = currentLang();
  const btn = (lang: "uk" | "en", flag: string, label: string) => (
    <button
      onClick={() => active !== lang && setLang(lang)}
      title={label}
      aria-label={label}
      className={`notranslate rounded-md p-0.5 transition-all ${
        active === lang ? "ring-2 ring-[#C0392B] bg-white" : "opacity-60 hover:opacity-100"
      }`}
    >
      <img src={`https://flagcdn.com/w40/${flag}.png`} alt={label} className="w-7 h-5 object-cover rounded-sm" />
    </button>
  );
  return (
    <div className="flex items-center gap-1.5 notranslate" translate="no">
      {btn("uk", "ua", "Українська")}
      {btn("en", "gb", "English")}
    </div>
  );
}
