import { useState } from "react";
import { Menu, X, ShoppingBasket, ShoppingCart } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import LanguageSwitcher from "./LanguageSwitcher";

const navLinks = [
  { label: "Головна", href: "#home" },
  { label: "Продукція", href: "#products" },
  { label: "Хіти продажів", href: "#featured" },
  { label: "Про нас", href: "#about" },
  { label: "Співпраця", href: "#partnership" },
  { label: "Контакти", href: "#contact" },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { totalItems, openCart } = useCart();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#FDF6EC]/95 backdrop-blur-md border-b border-[#F5E6D3] shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-2">
            <ShoppingBasket className="w-8 h-8 text-[#C0392B]" />
            <span className="font-['Playfair_Display'] text-xl md:text-2xl font-bold text-[#1A1A1A]">
              М'яс<span className="text-[#C0392B]">ничок</span>
            </span>
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-[#6B5B4F] hover:text-[#C0392B] font-medium transition-colors duration-200 text-sm tracking-wide uppercase"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Right side actions */}
          <div className="flex items-center gap-2 md:gap-3">
            <LanguageSwitcher />
            {/* Cart Button */}
            <button
              onClick={openCart}
              className="relative p-2.5 rounded-lg hover:bg-[#F5E6D3] transition-colors"
              aria-label="Відкрити кошик"
            >
              <ShoppingCart className="w-5 h-5 md:w-6 md:h-6 text-[#1A1A1A]" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#C0392B] text-white text-[10px] font-bold min-w-[20px] h-5 px-1 rounded-full flex items-center justify-center shadow-md">
                  {totalItems > 99 ? "99+" : totalItems}
                </span>
              )}
            </button>

            {/* CTA Button Desktop */}
            <a
              href="#products"
              className="hidden md:inline-flex items-center px-5 py-2.5 bg-[#C0392B] text-white font-semibold rounded-lg hover:bg-[#A93226] transition-colors duration-200 text-sm"
            >
              Замовити
            </a>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden p-2 text-[#1A1A1A]"
              aria-label="Меню"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {isOpen && (
          <div className="md:hidden pb-4 border-t border-[#F5E6D3]">
            <div className="flex flex-col gap-2 pt-4">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className="text-[#6B5B4F] hover:text-[#C0392B] font-medium py-2 px-2 rounded-lg hover:bg-[#F5E6D3] transition-colors duration-200"
                >
                  {link.label}
                </a>
              ))}
              <a
                href="#products"
                onClick={() => setIsOpen(false)}
                className="mt-2 inline-flex items-center justify-center px-5 py-2.5 bg-[#C0392B] text-white font-semibold rounded-lg hover:bg-[#A93226] transition-colors duration-200"
              >
                Замовити
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}