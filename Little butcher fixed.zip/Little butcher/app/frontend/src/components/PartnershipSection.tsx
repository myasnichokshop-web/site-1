import { useState } from "react";
import { createClient } from "@metagptx/web-sdk";
import { Handshake, CheckCircle2, Loader2 } from "lucide-react";

const client = createClient();

interface FormState {
  last_name: string;
  first_name: string;
  company: string;
  phone: string;
  message: string;
}

const emptyForm: FormState = { last_name: "", first_name: "", company: "", phone: "", message: "" };
const PHONE_RE = /^\+?[\d\s()-]{10,18}$/;

const fields: { key: keyof FormState; label: string; placeholder: string; type?: string }[] = [
  { key: "last_name", label: "Прізвище", placeholder: "Шевченко" },
  { key: "first_name", label: "Ім'я", placeholder: "Тарас" },
  { key: "company", label: "Підприємство / ФОП", placeholder: "ФОП Шевченко Т. Г." },
  { key: "phone", label: "Номер телефону", placeholder: "+380 67 123 45 67", type: "tel" },
];

export default function PartnershipSection() {
  const [form, setForm] = useState<FormState>(emptyForm);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [submitError, setSubmitError] = useState("");

  const validate = () => {
    const e: Partial<Record<keyof FormState, string>> = {};
    if (form.last_name.trim().length < 2) e.last_name = "Вкажіть прізвище";
    if (form.first_name.trim().length < 2) e.first_name = "Вкажіть ім'я";
    if (form.company.trim().length < 2) e.company = "Вкажіть назву підприємства";
    if (!PHONE_RE.test(form.phone.trim())) e.phone = "Вкажіть коректний номер, напр. +380 67 123 45 67";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    setSubmitError("");
    if (!validate()) return;
    setLoading(true);
    try {
      await client.entities.partnership_requests.create({
        data: {
          last_name: form.last_name.trim(),
          first_name: form.first_name.trim(),
          company: form.company.trim(),
          phone: form.phone.trim(),
          message: form.message.trim(),
        },
      });
      setSent(true);
      setForm(emptyForm);
    } catch {
      setSubmitError("Не вдалося надіслати заявку. Спробуйте ще раз.");
    } finally {
      setLoading(false);
    }
  };

  const inputCls = (err?: string) =>
    `w-full px-4 py-3 rounded-lg border bg-white text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#C0392B]/40 ${
      err ? "border-[#C0392B]" : "border-[#E0D5C7]"
    }`;

  return (
    <section id="partnership" className="py-20 md:py-28 bg-[#F5E6D3]/40">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <div className="flex items-center justify-center gap-2 mb-3">
            <Handshake className="w-5 h-5 text-[#C0392B]" />
            <span className="text-[#C0392B] uppercase tracking-widest text-sm font-semibold">Для бізнесу</span>
          </div>
          <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl font-bold text-[#1A1A1A] mb-4">Співпраця</h2>
          <p className="text-[#6B5B4F] text-lg">
            Ви підприємець і хочете співпрацювати з нами? Залиште свої контакти — ми зателефонуємо.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-[#E0D5C7] p-6 md:p-10">
          {sent ? (
            <div className="text-center py-8">
              <CheckCircle2 className="w-14 h-14 text-green-600 mx-auto mb-4" />
              <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#1A1A1A] mb-2">Дякуємо за заявку!</h3>
              <p className="text-[#6B5B4F] mb-6">Ми зв'яжемося з вами найближчим часом.</p>
              <button
                onClick={() => setSent(false)}
                className="px-6 py-3 rounded-lg bg-[#8B4513] text-white font-semibold hover:bg-[#6F370F]"
              >
                Надіслати ще одну заявку
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {fields.map((f) => (
                <div key={f.key}>
                  <label htmlFor={f.key} className="block text-sm font-semibold text-[#1A1A1A] mb-1.5">
                    {f.label} <span className="text-[#C0392B]">*</span>
                  </label>
                  <input
                    id={f.key}
                    type={f.type ?? "text"}
                    value={form[f.key]}
                    placeholder={f.placeholder}
                    onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                    className={inputCls(errors[f.key])}
                  />
                  {errors[f.key] && <p className="text-xs text-[#C0392B] mt-1">{errors[f.key]}</p>}
                </div>
              ))}
              <div className="md:col-span-2">
                <label htmlFor="message" className="block text-sm font-semibold text-[#1A1A1A] mb-1.5">
                  Повідомлення <span className="text-[#6B5B4F] font-normal">(необов'язково)</span>
                </label>
                <textarea
                  id="message"
                  rows={4}
                  value={form.message}
                  placeholder="Розкажіть, яка співпраця вас цікавить"
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className={inputCls()}
                />
              </div>
              {submitError && <p className="md:col-span-2 text-sm text-[#C0392B]">{submitError}</p>}
              <button
                type="submit"
                disabled={loading}
                className="md:col-span-2 flex items-center justify-center gap-2 px-6 py-3.5 rounded-lg bg-[#C0392B] text-white font-semibold hover:bg-[#A93226] disabled:opacity-60"
              >
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                Надіслати заявку
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
