import { useState, useMemo } from "react";
import { ShoppingCart, Filter, Baby, Layers } from "lucide-react";
import { useCart, parsePrice } from "@/contexts/CartContext";

const IMG = {
  butter250: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-24/xcjewkicaleq/butter-250.png",
  butter500: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-24/xcjewxicalea/butter-500.png",
  butter1000: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-24/xcjexeacaldq/butter-1000.png",
  yeastLvivski: "/assets/yeast-kharkivski.jpg",
  yeastZelenyiZmii: "/assets/yeast-zelenyi-zmii.jpg",
} as const;

type Category = "Ковбаси" | "М'ясні делікатеси" | "Снеки" | "Молочне" | "Випічка та фаст-фуд" | "Заморожені" | "Бакалія";

interface Variant {
  id: number;
  weight: string;
  price: string;
  image: string;
}

interface Product {
  id: number;
  name: string;
  category: Category;
  subType: string;
  description: string;
  price: string;
  weight: string;
  image: string;
  isChild?: boolean;
  variants?: Variant[];
}

const products: Product[] = [
  { id: 101, name: "Сосиски «Хот-дог» 1 с.", category: "Ковбаси", subType: "Сосиски та сардельки", description: "Соковиті сосиски та сардельки для швидкого сніданку чи гриля.", price: "140 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwcjqcalgq/p001.png" },
  { id: 102, name: "Сосиски філейні з сиром", category: "Ковбаси", subType: "Сосиски та сардельки", description: "Соковиті сосиски та сардельки для швидкого сніданку чи гриля.", price: "220 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwcwqcalga/p002.png" },
  { id: 103, name: "Сосиски віденські", category: "Ковбаси", subType: "Сосиски та сардельки", description: "Соковиті сосиски та сардельки для швидкого сніданку чи гриля.", price: "185 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwddicaliq/p003.png" },
  { id: 104, name: "Сардельки вершкові 1 с.", category: "Ковбаси", subType: "Сосиски та сардельки", description: "Соковиті сосиски та сардельки для швидкого сніданку чи гриля.", price: "165 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwdqacalia/p004.png" },
  { id: 105, name: "Сардельки козацькі", category: "Ковбаси", subType: "Сосиски та сардельки", description: "Соковиті сосиски та сардельки для швидкого сніданку чи гриля.", price: "175 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwd5acalhq/p005.png" },
  { id: 106, name: "Сардельки «Смачні»", category: "Ковбаси", subType: "Сосиски та сардельки", description: "Соковиті сосиски та сардельки для швидкого сніданку чи гриля.", price: "215 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwejycalha/p006.png" },
  { id: 107, name: "Ковбаса «Фермерська» 1 с.", category: "Ковбаси", subType: "Варені", description: "Ніжна варена ковбаса для бутербродів і сніданків.", price: "120 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwewqcalgq/p007.png" },
  { id: 108, name: "Ковбаса «Студентська» 1 с.", category: "Ковбаси", subType: "Варені", description: "Ніжна варена ковбаса для бутербродів і сніданків.", price: "130 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwfdqcalga/p008.png" },
  { id: 109, name: "Ковбаса «Молодіжна» (Вектор)", category: "Ковбаси", subType: "Варені", description: "Ніжна варена ковбаса для бутербродів і сніданків.", price: "135 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwfqicaliq/p009.png" },
  { id: 110, name: "Ковбаса «Вершкова» (Вектор) в/с", category: "Ковбаси", subType: "Варені", description: "Ніжна варена ковбаса для бутербродів і сніданків.", price: "150 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwf5acalia/p010.png" },
  { id: 111, name: "Ковбаса «Боярська»", category: "Ковбаси", subType: "Варені", description: "Ніжна варена ковбаса для бутербродів і сніданків.", price: "150 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwgjycalhq/p011.png" },
  { id: 112, name: "Ковбаса «Лікарська»", category: "Ковбаси", subType: "Варені", description: "Ніжна варена ковбаса для бутербродів і сніданків.", price: "165 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwgwqcalha/p012.png" },
  { id: 113, name: "Ковбаса «Індича»", category: "Ковбаси", subType: "Варені", description: "Ніжна варена ковбаса для бутербродів і сніданків.", price: "180 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwhdqaalgq/p013.png" },
  { id: 114, name: "Ковбаса «Теляча з вершками»", category: "Ковбаси", subType: "Варені", description: "Ніжна варена ковбаса для бутербродів і сніданків.", price: "180 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwhqicalga/p014.png" },
  { id: 115, name: "Ковбаса «Русанівська»", category: "Ковбаси", subType: "Варені", description: "Ніжна варена ковбаса для бутербродів і сніданків.", price: "190 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwh5acaliq/p015.png" },
  { id: 116, name: "Ковбаса «Шинкова» (Вектор) 1 с.", category: "Ковбаси", subType: "Варені", description: "Ніжна варена ковбаса для бутербродів і сніданків.", price: "200 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwijycalia/p016.png" },
  { id: 117, name: "Ковбаса «Традиційна з телятини» (Вектор) 1 с.", category: "Ковбаси", subType: "Варені", description: "Ніжна варена ковбаса для бутербродів і сніданків.", price: "205 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwiwqcalhq/p017.png" },
  { id: 118, name: "Ковбаса «Часникова»", category: "Ковбаси", subType: "Напівкопчені", description: "Ароматна напівкопчена ковбаса за домашнім рецептом.", price: "170 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwjdicalha/p018.png" },
  { id: 119, name: "Ковбаса «Домашня Польська» н/к 1 с.", category: "Ковбаси", subType: "Напівкопчені", description: "Ароматна напівкопчена ковбаса за домашнім рецептом.", price: "170 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwjqicalgq/p019.png" },
  { id: 120, name: "Ковбаса «Домашня куряча»", category: "Ковбаси", subType: "Напівкопчені", description: "Ароматна напівкопчена ковбаса за домашнім рецептом.", price: "220 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwj5acalga/p020.png" },
  { id: 121, name: "Ковбаса «Домашня мелена»", category: "Ковбаси", subType: "Напівкопчені", description: "Ароматна напівкопчена ковбаса за домашнім рецептом.", price: "300 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwkjycalia/p021.png" },
  { id: 122, name: "Ковбаса «Галицька»", category: "Ковбаси", subType: "Напівкопчені", description: "Ароматна напівкопчена ковбаса за домашнім рецептом.", price: "155 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwkwqcalhq/p022.png" },
  { id: 123, name: "Ковбаса «Довбушська»", category: "Ковбаси", subType: "Напівкопчені", description: "Ароматна напівкопчена ковбаса за домашнім рецептом.", price: "180 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwldicalha/p023.png" },
  { id: 124, name: "Ковбаса «Селянська»", category: "Ковбаси", subType: "Напівкопчені", description: "Ароматна напівкопчена ковбаса за домашнім рецептом.", price: "185 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwlqicalgq/p024.png" },
  { id: 125, name: "Салямі зі свинини", category: "Ковбаси", subType: "Копчені та сирокопчені", description: "Копчена ковбаса з насиченим смаком і ароматом диму.", price: "195 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwl5acalga/p025.png" },
  { id: 126, name: "Ковбаса «Сенаторська»", category: "Ковбаси", subType: "Копчені та сирокопчені", description: "Копчена ковбаса з насиченим смаком і ароматом диму.", price: "200 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwmjycaliq/p026.png" },
  { id: 127, name: "Ковбаски «Мисливські»", category: "Ковбаси", subType: "Копчені та сирокопчені", description: "Копчена ковбаса з насиченим смаком і ароматом диму.", price: "205 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwmwycalia/p027.png" },
  { id: 128, name: "Салямі «Домашня» в/к м'ясна", category: "Ковбаси", subType: "Копчені та сирокопчені", description: "Копчена ковбаса з насиченим смаком і ароматом диму.", price: "275 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwndqcalhq/p028.png" },
  { id: 129, name: "Ковбаса «Золотиста»", category: "Ковбаси", subType: "Копчені та сирокопчені", description: "Копчена ковбаса з насиченим смаком і ароматом диму.", price: "245 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwnqicalha/p029.png" },
  { id: 130, name: "Ковбаса «Три сири»", category: "Ковбаси", subType: "Копчені та сирокопчені", description: "Копчена ковбаса з насиченим смаком і ароматом диму.", price: "265 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwn5acalgq/p030.png" },
  { id: 131, name: "Ковбаса «Суха»", category: "Ковбаси", subType: "Копчені та сирокопчені", description: "Копчена ковбаса з насиченим смаком і ароматом диму.", price: "215 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwokaaalga/p031.png" },
  { id: 132, name: "Ковбаса «Сирний пан»", category: "Ковбаси", subType: "Копчені та сирокопчені", description: "Копчена ковбаса з насиченим смаком і ароматом диму.", price: "245 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwowycaliq/p032.png" },
  { id: 133, name: "Ковбаса «Філейна»", category: "Ковбаси", subType: "Копчені та сирокопчені", description: "Копчена ковбаса з насиченим смаком і ароматом диму.", price: "285 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwpdqcalia/p033.png" },
  { id: 134, name: "Ковбаса «Куряча» (батон)", category: "Ковбаси", subType: "Копчені та сирокопчені", description: "Копчена ковбаса з насиченим смаком і ароматом диму.", price: "275 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwpqicalhq/p034.png" },
  { id: 135, name: "Ковбаса «Рублена»", category: "Ковбаси", subType: "Копчені та сирокопчені", description: "Копчена ковбаса з насиченим смаком і ароматом диму.", price: "320 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwp5acalha/p035.png" },
  { id: 136, name: "Пастрома с/к", category: "Ковбаси", subType: "Копчені та сирокопчені", description: "Копчена ковбаса з насиченим смаком і ароматом диму.", price: "600 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwqkacalgq/p036.png" },
  { id: 137, name: "Вушка", category: "М'ясні делікатеси", subType: "Копченості", description: "М'ясний делікатес власного копчення.", price: "300 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwqwycalga/p037.png" },
  { id: 138, name: "Крильця курячі копчені", category: "М'ясні делікатеси", subType: "Копченості", description: "М'ясний делікатес власного копчення.", price: "200 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwrdqcaliq/p038.png" },
  { id: 139, name: "Гомілки курячі копчені", category: "М'ясні делікатеси", subType: "Копченості", description: "М'ясний делікатес власного копчення.", price: "200 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwrqicalia/p039.png" },
  { id: 140, name: "Філе куряче копчене", category: "М'ясні делікатеси", subType: "Копченості", description: "М'ясний делікатес власного копчення.", price: "280 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwr5acalhq/p040.png" },
  { id: 141, name: "Зельц м'ясний", category: "М'ясні делікатеси", subType: "Копченості", description: "М'ясний делікатес власного копчення.", price: "215 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwskaaalha/p041.png" },
  { id: 142, name: "Хлібець в/у", category: "М'ясні делікатеси", subType: "Копченості", description: "М'ясний делікатес власного копчення.", price: "175 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwswycalgq/p042.png" },
  { id: 143, name: "Шашлик курячий", category: "М'ясні делікатеси", subType: "Для гриля", description: "Готово до смаження на мангалі чи грилі.", price: "240 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwtdqcalga/p043.png" },
  { id: 144, name: "Шашличні ковбаски", category: "М'ясні делікатеси", subType: "Для гриля", description: "Готово до смаження на мангалі чи грилі.", price: "220 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwtqicaliq/p044.png" },
  { id: 145, name: "Барбекю", category: "М'ясні делікатеси", subType: "Для гриля", description: "Готово до смаження на мангалі чи грилі.", price: "300 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwt5acalia/p045.png" },
  { id: 146, name: "Кабаноси «Чікенз»", category: "Снеки", subType: "М'ясні", description: "М'ясний снек — ідеальна закуска.", price: "410 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwujycalhq/p046.png" },
  { id: 147, name: "М'ясні чіпси свинні", category: "Снеки", subType: "М'ясні", description: "М'ясний снек — ідеальна закуска.", price: "920 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwuwqcalha/p047.png" },
  { id: 148, name: "М'ясні чіпси курячі", category: "Снеки", subType: "М'ясні", description: "М'ясний снек — ідеальна закуска.", price: "830 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwvdicalgq/p048.png" },
  { id: 149, name: "М'ясні смужки з пармезаном", category: "Снеки", subType: "М'ясні", description: "М'ясний снек — ідеальна закуска.", price: "740 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwvqacalga/p049.png" },
  { id: 150, name: "М'ясо курки (та хамон 1 уп.)", category: "Снеки", subType: "М'ясні", description: "М'ясний снек — ідеальна закуска.", price: "840 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjwv5aaaliq/p050.png" },
  { id: 151, name: "Джерки м'ясні", category: "Снеки", subType: "М'ясні", description: "М'ясний снек — ідеальна закуска.", price: "1180 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzckicalhq/p051.png" },
  { id: 152, name: "Полосатик", category: "Снеки", subType: "Рибні", description: "Сушений рибний снек до пива.", price: "820 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzcxicalha/p052.png" },
  { id: 153, name: "Анчоус", category: "Снеки", subType: "Рибні", description: "Сушений рибний снек до пива.", price: "670 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzdeacalgq/p053.png" },
  { id: 154, name: "Кальмар стружка", category: "Снеки", subType: "Рибні", description: "Сушений рибний снек до пива.", price: "880 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzdqycalga/p054.png" },
  { id: 155, name: "Хворостець (минтай)", category: "Снеки", subType: "Рибні", description: "Сушений рибний снек до пива.", price: "720 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzd5ycaliq/p055.png" },
  { id: 156, name: "Льодяна спинка", category: "Снеки", subType: "Рибні", description: "Сушений рибний снек до пива.", price: "720 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzekqcalhq/p056.png" },
  { id: 157, name: "Спред «Волинське»", category: "Молочне", subType: "Масло та спреди", description: "Вершкове масло та спреди для кухні й випічки.", price: "45 ₴", weight: "шт.", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzexicalgq/p057.png" },
  { id: 158, name: "Масло «Щедрий вечір» Селянське 62,5%", category: "Молочне", subType: "Масло та спреди", description: "Вершкове масло та спреди для кухні й випічки.", price: "65 ₴", weight: "0,18 кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzfeicalga/p058.png" },
  { id: 159, name: "Масло «Щедрий вечір» Селянське 72,5%", category: "Молочне", subType: "Масло та спреди", description: "Вершкове масло та спреди для кухні й випічки.", price: "75 ₴", weight: "0,18 кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzfracaliq/p059.png" },
  { id: 160, name: "Масло «Щедрий вечір» Екстра 82%", category: "Молочне", subType: "Масло та спреди", description: "Вершкове масло та спреди для кухні й випічки.", price: "80 ₴", weight: "0,18 кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzf5ycalia/p060.png" },
  { id: 161, name: "Масло «Волинське» Селянське", category: "Молочне", subType: "Масло та спреди", description: "Вершкове масло та спреди для кухні й випічки.", price: "115 ₴", weight: "0,5 кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzgkqcalhq/p061.png" },
  { id: 162, name: "Масло «Волинське» Преміум", category: "Молочне", subType: "Масло та спреди", description: "Вершкове масло та спреди для кухні й випічки.", price: "135 ₴", weight: "0,5 кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzgxicalha/p062.png" },
  { id: 163, name: "Масло «Домашнє»", category: "Молочне", subType: "Масло та спреди", description: "Вершкове масло та спреди для кухні й випічки.", price: "145 ₴", weight: "0,5 кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzheacaliq/p063.png" },
  { id: 164, name: "Масло «Фермерське»", category: "Молочне", subType: "Масло та спреди", description: "Вершкове масло та спреди для кухні й випічки.", price: "150 ₴", weight: "0,5 кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzhracalhq/p064.png" },
  { id: 165, name: "Спред Класичний «Щедрий вечір» 72,5%", category: "Молочне", subType: "Масло та спреди", description: "Вершкове масло та спреди для кухні й випічки.", price: "170 ₴", weight: "кг (фас. 5 кг)", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzh5ycalha/p065.png" },
  { id: 166, name: "Спред Преміум «Щедрий вечір» 72,5%", category: "Молочне", subType: "Масло та спреди", description: "Вершкове масло та спреди для кухні й випічки.", price: "220 ₴", weight: "кг (фас. 5 кг)", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzikqcalgq/p066.png" },
  { id: 167, name: "Масло Екстра 72,5%", category: "Молочне", subType: "Масло та спреди", description: "Вершкове масло та спреди для кухні й випічки.", price: "290 ₴", weight: "кг (фас. 5 кг)", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzixicalga/p067.png" },
  { id: 168, name: "Масло Селянське Преміум", category: "Молочне", subType: "Масло та спреди", description: "Вершкове масло та спреди для кухні й випічки.", price: "320 ₴", weight: "кг (фас. 5–10 кг)", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzjeicaliq/p068.png" },
  { id: 169, name: "Тако", category: "Випічка та фаст-фуд", subType: "Лаваш і тортильї", description: "Свіжа випічка на кожен день.", price: "31 ₴", weight: "уп. 8 шт.", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzjracalia/p069.png" },
  { id: 170, name: "Лаваш", category: "Випічка та фаст-фуд", subType: "Лаваш і тортильї", description: "Свіжа випічка на кожен день.", price: "30 ₴", weight: "2 шт., 210 г", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzj5ycalha/p070.png" },
  { id: 171, name: "Тортилья до піци", category: "Випічка та фаст-фуд", subType: "Лаваш і тортильї", description: "Свіжа випічка на кожен день.", price: "55 ₴", weight: "уп. 2 шт.", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzkkycalgq/p071.png" },
  { id: 172, name: "Тортилья гриль", category: "Випічка та фаст-фуд", subType: "Лаваш і тортильї", description: "Свіжа випічка на кожен день.", price: "55 ₴", weight: "уп. 2 шт.", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzkxqcalga/p072.png" },
  { id: 173, name: "Багет (в асортименті)", category: "Випічка та фаст-фуд", subType: "Лаваш і тортильї", description: "Свіжа випічка на кожен день.", price: "50 ₴", weight: "шт.", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzleicaliq/p073.png" },
  { id: 174, name: "Піца тернопільська міні", category: "Випічка та фаст-фуд", subType: "Готова їжа", description: "Готова страва — розігрій і смакуй.", price: "42 ₴", weight: "шт.", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzlricalia/p074.png" },
  { id: 175, name: "Піца середня", category: "Випічка та фаст-фуд", subType: "Готова їжа", description: "Готова страва — розігрій і смакуй.", price: "58 ₴", weight: "шт.", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzl6acalhq/p075.png" },
  { id: 176, name: "Піца велика", category: "Випічка та фаст-фуд", subType: "Готова їжа", description: "Готова страва — розігрій і смакуй.", price: "90 ₴", weight: "шт.", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzmkycalgq/p076.png" },
  { id: 177, name: "Гамбургер", category: "Випічка та фаст-фуд", subType: "Готова їжа", description: "Готова страва — розігрій і смакуй.", price: "46 ₴", weight: "шт.", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzmxqcalga/p077.png" },
  { id: 178, name: "Паніні", category: "Випічка та фаст-фуд", subType: "Готова їжа", description: "Готова страва — розігрій і смакуй.", price: "46 ₴", weight: "шт.", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzneicaliq/p078.png" },
  { id: 179, name: "Хот-дог", category: "Випічка та фаст-фуд", subType: "Готова їжа", description: "Готова страва — розігрій і смакуй.", price: "43 ₴", weight: "шт.", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjznracalia/p079.png" },
  { id: 180, name: "Сирок плавлений", category: "Молочне", subType: "Сири", description: "Сир від перевірених виробників.", price: "15 ₴", weight: "75 г", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzn5ycalhq/p080.png" },
  { id: 181, name: "Сирок плавлений ДСТУ", category: "Молочне", subType: "Сири", description: "Сир від перевірених виробників.", price: "20 ₴", weight: "75 г", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzokycalha/p081.png" },
  { id: 182, name: "Сирок тостерний", category: "Молочне", subType: "Сири", description: "Сир від перевірених виробників.", price: "42 ₴", weight: "уп.", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzoxqcaliq/p082.png" },
  { id: 183, name: "Сир «Добра Справа» (фас.)", category: "Молочне", subType: "Сири", description: "Сир від перевірених виробників.", price: "230 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzpeicalha/p083.png" },
  { id: 184, name: "Сир Моцарела сулугуні", category: "Молочне", subType: "Сири", description: "Сир від перевірених виробників.", price: "240 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzpxicalgq/p084.png" },
  { id: 185, name: "Сир копчений на дровах в/у", category: "Молочне", subType: "Сири", description: "Сир від перевірених виробників.", price: "230 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzqeicalga/p085.png" },
  { id: 186, name: "Продукт сирний нитка / косичка", category: "Молочне", subType: "Сири", description: "Сир від перевірених виробників.", price: "265 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzqracaliq/p086.png" },
  { id: 187, name: "Сир соломка / косичка", category: "Молочне", subType: "Сири", description: "Сир від перевірених виробників.", price: "320 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzq5ycalia/p087.png" },
  { id: 188, name: "Сир павутинка", category: "Молочне", subType: "Сири", description: "Сир від перевірених виробників.", price: "345 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzrkqcalhq/p088.png" },
  { id: 189, name: "Сир бамбук", category: "Молочне", subType: "Сири", description: "Сир від перевірених виробників.", price: "350 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzrxqcalgq/p089.png" },
  { id: 190, name: "Сир косичка біла", category: "Молочне", subType: "Сири", description: "Сир від перевірених виробників.", price: "355 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzseicalga/p090.png" },
  { id: 191, name: "Сир кисломолочний", category: "Молочне", subType: "Сири", description: "Сир від перевірених виробників.", price: "105 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzsracaliq/p091.png" },
  { id: 192, name: "Сметана «Подільська» 21%", category: "Молочне", subType: "Сметана", description: "Густа сметана 21% жирності.", price: "38 ₴", weight: "пакет 0,4 кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzs5ycalia/p092.png" },
  { id: 193, name: "Сметана «Подільська» 21%", category: "Молочне", subType: "Сметана", description: "Густа сметана 21% жирності.", price: "82 ₴", weight: "відро 0,9 кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjztracalhq/p093.png" },
  { id: 194, name: "Вареники з картоплею та цибулею", category: "Заморожені", subType: "Вареники", description: "Заморожені вареники ручної ліпки.", price: "95 ₴", weight: "кг (фас. 2,5 кг)", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzt5ycalgq/p094.png" },
  { id: 195, name: "Вареники з картоплею та цибулею", category: "Заморожені", subType: "Вареники", description: "Заморожені вареники ручної ліпки.", price: "100 ₴", weight: "кг (фас. 1 кг)", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzukqcalga/p095.png" },
  { id: 196, name: "Вареники з сиром", category: "Заморожені", subType: "Вареники", description: "Заморожені вареники ручної ліпки.", price: "150 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzuxqcaliq/p096.png" },
  { id: 197, name: "Пельмені «Козацькі»", category: "Заморожені", subType: "Пельмені", description: "Заморожені пельмені з м'ясною начинкою.", price: "115 ₴", weight: "кг", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzveicalia/p097.png" },
  { id: 198, name: "Пельмені «Сонечко»", category: "Заморожені", subType: "Пельмені", description: "Заморожені пельмені з м'ясною начинкою.", price: "105 ₴", weight: "кг (фас. 2,5 кг)", image: "https://mgx-backend-cdn.metadl.com/generate/images/1072760/2026-09-25/xfjzvracalhq/p098.png" },

  // ===== БАКАЛІЯ =====
  {
    id: 83, name: "Масло вершкове 82%", category: "Бакалія", subType: "Масло",
    description: "Натуральне вершкове масло 82% жирності з фермерських вершків. Оберіть вагу: 250 г, 500 г або 1000 г.",
    price: "95 ₴", weight: "250 г", image: IMG.butter250,
    variants: [
      { id: 8301, weight: "250 г", price: "95 ₴", image: IMG.butter250 },
      { id: 8302, weight: "500 г", price: "185 ₴", image: IMG.butter500 },
      { id: 8303, weight: "1000 г", price: "359 ₴", image: IMG.butter1000 },
    ],
  },
  { id: 84, name: "Дріжджі «Харківські»", category: "Бакалія", subType: "Дріжджі", description: "Свіжі пресовані хлібопекарські дріжджі для пишного тіста, домашнього хліба та здоби.", price: "14 ₴", weight: "100 г", image: IMG.yeastLvivski },
  { id: 85, name: "Дріжджі «Зелений змій»", category: "Бакалія", subType: "Дріжджі", description: "Спиртові дріжджі для бродіння та приготування домашніх напоїв. Фасування — лише 500 г.", price: "48 ₴", weight: "500 г", image: IMG.yeastZelenyiZmii },
];

const categories: Category[] = ["Ковбаси", "М'ясні делікатеси", "Снеки", "Молочне", "Випічка та фаст-фуд", "Заморожені", "Бакалія"];

const subTypesByCategory: Record<Category, string[]> = {
  "Ковбаси": ["Всі", "Сосиски та сардельки", "Варені", "Напівкопчені", "Копчені та сирокопчені"],
  "М'ясні делікатеси": ["Всі", "Копченості", "Для гриля"],
  "Снеки": ["Всі", "М'ясні", "Рибні"],
  "Молочне": ["Всі", "Масло та спреди", "Сири", "Сметана"],
  "Випічка та фаст-фуд": ["Всі", "Лаваш і тортильї", "Готова їжа"],
  "Заморожені": ["Всі", "Вареники", "Пельмені"],
  "Бакалія": ["Всі", "Масло", "Дріжджі"],
};

const catalogLabelByCategory: Record<Category, string> = {
  "Ковбаси": "Види ковбас",
  "М'ясні делікатеси": "Види делікатесів",
  "Снеки": "Види снеків",
  "Молочне": "Молочна продукція",
  "Випічка та фаст-фуд": "Випічка та готова їжа",
  "Заморожені": "Заморожені вироби",
  "Бакалія": "Види бакалії",
};

export default function ProductCatalog() {
  const [activeCategory, setActiveCategory] = useState<Category>("Ковбаси");
  const [activeSubType, setActiveSubType] = useState<string>("Всі");
  const { addItem } = useCart();
  const [selectedVariant, setSelectedVariant] = useState<Record<number, number>>({});

  const resolve = (product: Product): Product => {
    const v = product.variants?.[selectedVariant[product.id] ?? 0];
    return v ? { ...product, id: v.id, name: `${product.name}, ${v.weight}`, price: v.price, weight: v.weight, image: v.image } : product;
  };

  const handleCategoryChange = (cat: Category) => {
    setActiveCategory(cat);
    setActiveSubType("Всі");
  };

  const handleAdd = (product: Product) => {
    addItem({
      id: product.id,
      name: product.name,
      price: parsePrice(product.price),
      priceLabel: product.price,
      weight: product.weight,
      image: product.image,
      category: product.category,
    });
  };

  const filteredProducts = useMemo(() => {
    let filtered = products.filter((p) => p.category === activeCategory);
    if (activeSubType !== "Всі") {
      filtered = filtered.filter((p) => p.subType === activeSubType);
    }
    return filtered;
  }, [activeCategory, activeSubType]);

  const currentSubTypes = subTypesByCategory[activeCategory];

  return (
    <section id="products" className="py-20 md:py-28 bg-[#F5E6D3]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="text-[#C0392B] uppercase tracking-widest text-sm font-semibold">
            Наш асортимент
          </span>
          <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl font-bold text-[#1A1A1A] mt-2 mb-4">
            Каталог продукції
          </h2>
          <p className="text-[#6B5B4F] text-lg max-w-2xl mx-auto">
            Оберіть категорію — і одразу побачите всі види продукції у ній.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-8">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => handleCategoryChange(cat)}
              className={`px-8 py-3 rounded-full font-semibold text-sm transition-all duration-200 ${
                activeCategory === cat
                  ? "bg-[#8B4513] text-white shadow-md"
                  : "bg-white text-[#6B5B4F] hover:bg-[#F5E6D3] border border-[#E0D5C7]"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Sub-Type Filter — always visible for the active category */}
        <div className="bg-white/70 border border-[#E0D5C7] rounded-2xl p-4 md:p-5 mb-10">
          <div className="flex items-center gap-2 mb-3">
            <Layers className="w-4 h-4 text-[#8B4513]" />
            <span className="text-sm font-semibold text-[#8B4513] uppercase tracking-wider">
              {catalogLabelByCategory[activeCategory]}
            </span>
            <Filter className="w-3.5 h-3.5 text-[#8B4513]/60" />
            <span className="text-xs text-[#6B5B4F] ml-auto hidden sm:inline">
              {filteredProducts.length} позицій
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {currentSubTypes.map((sub) => (
              <button
                key={sub}
                onClick={() => setActiveSubType(sub)}
                className={`px-4 py-2 rounded-full text-xs md:text-sm font-medium transition-all duration-200 ${
                  activeSubType === sub
                    ? "bg-[#C0392B] text-white shadow-sm"
                    : "bg-white text-[#6B5B4F] hover:bg-[#F5E6D3] border border-[#E0D5C7]"
                }`}
              >
                {sub}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className={`group bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border ${
                product.isChild ? "border-green-300 ring-1 ring-green-200" : "border-[#F5E6D3]"
              }`}
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={resolve(product).image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 right-3 flex gap-1.5">
                  {product.isChild && (
                    <span className="bg-green-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
                      <Baby className="w-3 h-3" />
                      Дитяча
                    </span>
                  )}
                  <span className="bg-[#8B4513]/90 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wide">
                    {product.subType}
                  </span>
                </div>
              </div>
              <div className="p-5">
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-[#8B4513] text-xs font-semibold uppercase tracking-wider">
                    {product.category}
                  </p>
                  {product.isChild && (
                    <span className="text-[10px] bg-green-100 text-green-700 font-semibold px-2 py-0.5 rounded-full">
                      100% натуральна
                    </span>
                  )}
                </div>
                <h3 className="font-['Playfair_Display'] text-lg font-bold text-[#1A1A1A] mb-2">
                  {product.name}
                </h3>
                <p className="text-[#6B5B4F] text-sm leading-relaxed mb-4 line-clamp-2">
                  {product.description}
                </p>
                {product.variants && (
                  <div className="flex gap-2 mb-4">
                    {product.variants.map((v, i) => (
                      <button
                        key={v.id}
                        onClick={() => setSelectedVariant((s) => ({ ...s, [product.id]: i }))}
                        className={`flex-1 px-2 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                          (selectedVariant[product.id] ?? 0) === i
                            ? "bg-[#C0392B] text-white border-[#C0392B]"
                            : "bg-white text-[#6B5B4F] border-[#E0D5C7] hover:bg-[#F5E6D3]"
                        }`}
                      >
                        {v.weight}
                      </button>
                    ))}
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xl font-bold text-[#C0392B]">{resolve(product).price}</span>
                    <span className="text-xs text-[#6B5B4F] ml-1">/ {resolve(product).weight}</span>
                  </div>
                  <button
                    onClick={() => handleAdd(resolve(product))}
                    className="flex items-center gap-1.5 px-3 py-2 bg-[#1A1A1A] text-white text-xs font-semibold rounded-lg hover:bg-[#333] transition-colors duration-200"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    Додати
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-16">
            <p className="text-[#6B5B4F] text-lg">Товарів за цим фільтром не знайдено.</p>
          </div>
        )}
      </div>
    </section>
  );
}
