import "@fontsource/playfair-display/400.css";
import "@fontsource/playfair-display/500.css";
import "@fontsource/playfair-display/600.css";
import "@fontsource/playfair-display/700.css";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import "@fontsource/inter/700.css";

import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import FeaturedProducts from "@/components/FeaturedProducts";
import ProductCatalog from "@/components/ProductCatalog";
import AboutSection from "@/components/AboutSection";
import PartnershipSection from "@/components/PartnershipSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import { CartProvider } from "@/contexts/CartContext";

export default function Index() {
  return (
    <CartProvider>
      <div className="min-h-screen bg-[#FDF6EC] font-['Inter']">
        <Navbar />
        <HeroSection />
        <FeaturedProducts />
        <ProductCatalog />
        <AboutSection />
        <PartnershipSection />
        <ContactSection />
        <Footer />
        <CartDrawer />
      </div>
    </CartProvider>
  );
}