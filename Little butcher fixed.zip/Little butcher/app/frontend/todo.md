# Armenian Delicatessen Website - Development Plan

## Design Guidelines

### Design References
- **Warm, artisan food market aesthetic** — earthy tones, rustic textures, premium feel
- **Style**: Warm Rustic + Modern Clean + Food-Forward

### Color Palette
- Primary: #1A1A1A (Deep Charcoal - text/headers)
- Secondary: #8B4513 (Saddle Brown - accents, Armenian warmth)
- Accent: #C0392B (Deep Red - CTAs, highlights)
- Background: #FDF6EC (Warm Cream - main background)
- Card BG: #FFFFFF (White - cards)
- Muted: #F5E6D3 (Light Tan - section backgrounds)
- Text Secondary: #6B5B4F (Warm Gray)

### Typography
- Headings: Playfair Display (serif, elegant, traditional feel)
- Body: Inter (clean, readable sans-serif)
- Heading1: Playfair Display 700 (48px)
- Heading2: Playfair Display 600 (36px)
- Heading3: Playfair Display 600 (24px)
- Body: Inter 400 (16px)
- Small: Inter 400 (14px)

### Key Component Styles
- **Buttons**: Deep Red (#C0392B), white text, 8px rounded, hover darken
- **Cards**: White bg, subtle shadow, 12px rounded, hover lift effect
- **Filters**: Pill-style tabs with brown accent for active state
- **Section dividers**: Subtle warm gradient lines

### Images to Generate
1. **hero-armenian-feast.jpg** - Overhead shot of a rustic wooden table with artisan sausages, various cheeses, and Armenian lavash bread, warm lighting, food photography style (1024x576)
2. **sausages-display.jpg** - Assortment of cured and smoked sausages (basturma, soujouk) on a wooden cutting board with herbs and spices (1024x1024)
3. **cheese-selection.jpg** - Beautiful arrangement of Armenian and Georgian cheeses (string cheese, suluguni) on a marble board with grapes and walnuts (1024x1024)
4. **lavash-bread.jpg** - Fresh Armenian lavash flatbread being pulled from a traditional tonir oven, warm golden tones (1024x1024)

---

## Development Tasks & Files

### Files to Create (max 8):
1. **src/pages/Index.tsx** - Main homepage with all sections (Hero, Featured, Products, About, Contact)
2. **src/components/Navbar.tsx** - Responsive navigation header with logo
3. **src/components/HeroSection.tsx** - Full-width hero banner
4. **src/components/ProductCatalog.tsx** - Product catalog with category tabs + sub-type filters + product cards
5. **src/components/FeaturedProducts.tsx** - Best sellers / featured section
6. **src/components/AboutSection.tsx** - About us section with Armenian heritage story
7. **src/components/ContactSection.tsx** - Contact info, hours, location
8. **src/components/Footer.tsx** - Footer with social links and newsletter

### Product Data (embedded in ProductCatalog):
- **Sausages**: Beef Basturma, Soujouk, Smoked Pork Sausage, Chicken Sausage
- **Cheeses**: String Cheese, Lori Cheese, Chanakh Cheese, Suluguni Cheese
- **Flatbread**: Classic Lavash, Thin Lavash, Matnakash, Tonir Bread